"""GymBuddyWeb URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from accounts.views import logoutView, registerView, loginView, baseView
from contact.views import contact
from home.views import home
from submit_video.views import submit_video_landing_page
from data_apis.SaveVideo import SubmitVideo
from data_apis.ProcessVideo import getProcessJob
from PreLoadedVideo.views import LoadedVideo
from report_viewer.views import RV
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/login/', loginView, name='login'),
    path('accounts/register/', registerView, name='signup'),
    path('accounts/logout', logoutView, name='logout'),
    path('', home, name='home'),
    path('contact', contact, name='contact'),
    path('SV', submit_video_landing_page, name='submit_video'),
    path('RequestJob', SubmitVideo, name="save_video"),
    path("LV", LoadedVideo, name="loaded_video"),
    path("ReportViewer", RV, name="report_viewer"),
    path("ProcessJob", getProcessJob, name="process_job")
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
