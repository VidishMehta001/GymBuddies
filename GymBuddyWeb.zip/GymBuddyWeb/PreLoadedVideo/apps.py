from django.apps import AppConfig


class PreloadedvideoConfig(AppConfig):
    name = 'PreLoadedVideo'
