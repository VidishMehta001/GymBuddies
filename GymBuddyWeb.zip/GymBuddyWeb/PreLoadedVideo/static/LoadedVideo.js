// Form Validation prior to clicking next
$(document).ready(function(){

    // Upon the clicking of the next button
    $("#loaded-next").click(function(event){
        //prevent page from refreshing
        event.preventDefault();
        
        //Check if the form is validated
        isValidated = ValidateForm()

        //Check if the isValidated is False
        if (isValidated === true){

            if ($("#Loaded-Video-Type").val()==="RGB"){
                console.log("Video type is RGB");
                console.log($("#Loaded-Video-Exercise").val());
                if ($("#Loaded-Video-Exercise").val()==="Push-ups"){
                    console.log("its coming here!")
                    $("#Video-Submitted").empty();
                    $("#Video-Submitted").append(
                        `
                        <div class="row justify-content-center">
                            <video width="780" height="380" src="/static/assets/video/v1_pushups_mono.mp4" loop autoplay muted controls></video>
                        </div>
                        <div class="row justify-content-center" style="padding: 10px;">
                            <button class="btn btn-success" id="Loaded-Submit-Video" style="width: 10%; font-size: large; text-align: center; align-items: left; margin-bottom: 1%;">Submit</button>
                        </div>
                        `
                    )

                }
                else if ($("#Loaded-Video-Exercise").val()==="Squats"){
                    $("#Video-Submitted").empty();
                    $("#Video-Submitted").append(
                        `
                        <div class="row justify-content-center">
                            <video width="780" height="380" src="/static/assets/video/v1_squats_color.mp4" codecs="av01.0.00M.08, opus" loop autoplay muted controls></video>
                        </div>
                        <div class="row justify-content-center" style="padding: 10px;">
                            <button class="btn btn-success" id="Loaded-Submit-Video" style="width: 10%; font-size: large; text-align: center; align-items: left; margin-bottom: 1%;">Submit</button>
                        </div>

                        `
                    )
                }

            }
            else if ($("#Loaded-Video-Type").val()==="RGB-D"){
                console.log("Video Type is RGB-D");
                // video_num and angle initialisation
                var video_num = $("#Loaded-Video-Number").val();
                var video_angle = $("#Loaded-Video-Angle").val();

                if ($("#Loaded-Video-Exercise").val()==="Push-ups"){
                    
                    if (video_angle==="45"){
                        var exercise = "pushups_45"
                    }
                    else {
                        var exercise = "pushups"
                    }
                   
                    var video_file_directory =  "v"+ video_num + "_" + exercise

                    $("#Video-Submitted").empty();
                    $("#Video-Submitted").append(
                        `
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <h3 class="h3" style="text-align: center; padding: 10px;">RGB Video</h3>
                                <video width="780" height="380" src="/static/assets/video/`+video_file_directory+`_mono2.mp4"loop autoplay muted controls></video>
                            </div>
                            <div class="col-lg-5">
                                <h3 class="h3" style="text-align: center; padding: 10px;">Depth Map</h3>
                                <video width="780" height="380" src="/static/assets/video/`+video_file_directory+`_depth.mp4" loop autoplay muted controls></video>
                            </div>
                        </div>
                        <div class="row justify-content-center" style="padding: 10px;">
                            <button class="btn btn-success" id="Loaded-Submit-Video" style="width: 10%; font-size: large; text-align: center; align-items: left; margin-bottom: 1%;">Submit</button>
                        </div>
                          
                        `
                    )
                }
                else if ($("#Loaded-Video-Exercise").val()==="Squats"){

                    if (video_angle==="45"){
                        var exercise = "squats_45"
                    }
                    else {
                        var exercise = "squats"
                    }
                   
                    var video_file_directory =  video_num + "_" + exercise


                    $("#Video-Submitted").empty();
                    $("#Video-Submitted").append(
                        `
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <h3 class="h3" style="text-align: center; padding: 10px;">RGB Video</h3>
                                <video width="780" height="380" src="/static/assets/video/v1_squats_mono2.mp4" loop autoplay muted controls></video>
                            </div>
                            <div class="col-lg-5">
                                <h3 class="h3" style="text-align: center; padding: 10px;">Depth Map</h3>
                                <video width="780" height="380" src="/static/assets/video/v1_squats_depth.mp4" loop autoplay muted controls></video>
                            </div>
                        </div>
                        <div class="row justify-content-center" style="padding: 10px;">
                            <button class="btn btn-success" id="Loaded-Submit-Video" style="width: 10%; font-size: large; text-align: center; align-items: left; margin-bottom: 1%;">Submit</button>
                        </div>
                          
                        `

                    )
                }


            }

        }

        $("#Loaded-Submit-Video").click(function(event){
            //Prevent default event
            event.preventDefault();

            var video_type = $("#Loaded-Video-Type").val();
            var video_exercise = $("#Loaded-Video-Exercise").val();
            var video_num = $("#Loaded-Video-Number").val();
            var video_angle = $("#Loaded-Video-Angle").val();
            
            if (video_angle==="45" & video_exercise==="Squats"){
                var exercise = "squats_45"
            }
            else if (video_angle==="45" & video_exercise==="Push-ups")  {
                var exercise = "pushups_45"
            }
            else if (video_angle != "45" & video_exercise==="Push-ups") {
                var exercise = "pushups"
            }
            else if (video_angle != "45" & video_exercise==="Squats") {
                var exercise = "squats"
            }
            
            var video_directory = exercise + "_" + video_num + "_" + "output"
            console.log(video_directory);


            // csrf token initialisation for api endpoint call to django backend
            var $csrf_token = getCookie('csrftoken');
            console.log($csrf_token);

            //formulate the formData
            formData = {"Video_Type": video_type, "Video_Exercise": video_exercise}

            //setup the url
            report_viewer_url = "/ReportViewer"
            
            //Check that the Video-Submitted is not empty
            if ($("#Video-Submitted").length > 0){
        
                // Empty Loaded-Request-Input
                $("#Loaded-Request-Input").empty()
                $("#Loaded-Request-Input").append(
                    `
                    <div id="progress-checker" class="row justify-content-center" style="margin-bottom: 10%;">
                        <div id="progress-bar" style="margin-top: 20%; margin-left:10%; width: 50%; padding: 10px;">
                            <h2 class="h2">Processing</h2>
                        </div>
                        <div class="progress" style="width: 50%;">
                            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
                        </div>
                    </div>

                    `
                    )

                setTimeout(function(){
                    
                    $("#Loaded-Request-Input").empty();
                    

                    if (video_exercise === "Push-ups"){
                        $("#Loaded-Request-Input").append(
                            `
                            <div class="jumbotron jumbotron-fluid" style="width:100%; height:100%; background-color:whitesmoke; min-height: 600px;">
    
                                <div class="row justify-content-center" style="margin-bottom: 2%; margin-top:10%;">
                                    <div class="col-lg-6">
                                        <h3 class="h3" style="text-align: left; padding: 10px; margin-left: 40px;">Exercise: `+exercise+` Version `+video_num+`</h3>
                                        <video width="860" height="640" src="/static/assets/video/`+video_directory+`.mp4" loop autoplay muted controls></video>
                                    </div>
                                    <div class="col-lg-1" style="margin-top: 12%;">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                            <th scope="col">Repetition Counts</th>
                                            <th scope="col">Valid Counts</th>
                                            <th scope="col">Broken Rules</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                            <td>4</td>
                                            <td>1</td>
                                            <td>Raise your body higher! Straighten your leg!</td>
                                            </tr>
                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div id="accordion" style="width: 70%; margin-left: 20%; margin-bottom: 5%;">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                Broken Rules
                                            </button>
                                        </h5>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                        <div class="card-body" id="broken-rules-imgs">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            `
                        )
                        $("#broken-rules-imgs").append(`
                        <img src="/static/assets/img/project/pushups/v1/251.jpg"></img>        
                        `)

                    }
                    else if (video_exercise === "Squats") {
                        $("#Loaded-Request-Input").append(
                        `
                        <div class="jumbotron jumbotron-fluid" style="width:100%; height:100%; background-color:whitesmoke; min-height: 600px;">
    
                                <div class="row justify-content-center" style="margin-bottom: 2%; margin-top:10%;">
                                    <div class="col-lg-6">
                                        <h3 class="h3" style="text-align: left; padding: 10px; margin-left: 40px;">Exercise: `+exercise+`; Video: `+video_num+`</h3>
                                        <video width="1080" height="640" src="/static/assets/video/`+video_directory+`.mp4" loop autoplay muted controls></video>
                                    </div>
                                </div>
                            </div>

                            <div id="accordion" style="width: 70%">
                                <div class="card">
                                    <div class="card-header" id="headingOne">
                                        <h5 class="mb-0">
                                            <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                Broken Rules
                                            </button>
                                        </h5>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                        <div class="card-body" id="broken-rules-imgs">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        `

                        )
                        $("#broken-rules-imgs").append(`
                        <img src="/static/assets/img/project/squats/v1/236.jpg"></img>        
                        `)

                        


                    }

                }, 5000);
                    
            
            }
    
    
        })


    })


})


// On Submit
$(document).ready(function(){

    $("#Loaded-Submit-Video").click(function(event){
        console.log("its coming here!")

        //Prevent default event
        event.preventDefault();

        //Check that the Video-Submitted is not empty
        if ($("#Video-Submitted").length > 0){

            console.log("its coming here!")

            // Empty Loaded-Request-Input
            $("#Loaded-Request-Input").empty()
            $("#Loaded-Request-Input").append(
                `
                <div id="progress-bar">
                    <h2 class="h2">Processing</h2>
                </div>
                
                `
            
                )

            
            
        
        
        }


    })


})

var i = 0;

// Validate the form
function ValidateForm(){
    // Is Validated
    var isValidated = true;
    
    //Check if the video type is not empty
    if ($("#Loaded-Video-Type").length===0){
        isValidated = false;
        return isValidated
    }

    // Check if the video is selected
    if ($("#Loaded-Video-Exercise").length===0){
        isValidated = false;
        return isValidated
    }

    return isValidated
}


