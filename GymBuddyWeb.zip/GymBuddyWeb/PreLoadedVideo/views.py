from django.shortcuts import render

# Create your views here.
def LoadedVideo(request, *args, **kwargs):
    return render(request, 'PreLoadedVideo.html', {})