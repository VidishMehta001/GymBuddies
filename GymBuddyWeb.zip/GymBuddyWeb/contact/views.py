from django.shortcuts import render

# Create your views here.

# Load the contact page
def contact(request, *args, **kwargs):
    return render(request, 'contact.html', {})
    