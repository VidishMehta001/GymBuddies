from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
import uuid
from django.http.multipartparser import MultiPartParser
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from django.core.files.storage import default_storage


@api_view(('GET',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))

def getProcessJob(request, format=None):
    print("Its coming here!!")
    return render(request, 'signup.html', {})