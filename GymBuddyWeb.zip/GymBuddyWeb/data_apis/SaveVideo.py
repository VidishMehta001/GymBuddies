from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import redirect
from django.contrib.auth.models import User
import uuid
from django.http.multipartparser import MultiPartParser
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from django.core.files.storage import default_storage


@api_view(('POST',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))
def SubmitVideo(request, format=None):

    if request.method == 'POST':

        form_data = dict(request.data)
        if form_data.get("File-type")[0]=="RGB":
            uploaded_file = form_data.get("VideoFile", [None])[0]
            file_name = str(uploaded_file.name)

            with default_storage.open('RGB/tmp/'+file_name, 'wb+') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)

            data_packet = {"File_name": file_name, "File_destination": "RGB/tmp/{}".format(file_name)}
        else:
            # Extract the video file
            uploaded_file = form_data.get("VideoFile", [None])[0]
            # Extract the depth map
            uploaded_depth_map = form_data.get("DepthMap", [None])[0]

            # get the file name for the video file and depthmap
            video_file_name = uploaded_file.name
            depth_file_name = uploaded_depth_map.name

            #Save the video file
            with default_storage.open("RGBD/tmp/"+ video_file_name, 'wb+') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)

            #Save the depth map
            with default_storage.open("RGBD/tmp/"+depth_file_name, "wb+") as destination:
                for chunk in uploaded_depth_map.chunks():
                    destination.write(chunk)

            # Create the datapacket
            data_packet = {"Video_file_name": video_file_name, 
                            "Depth_file_name": depth_file_name, 
                            "Video_file_destination": "RGBD/tmp/{}".format(video_file_name),
                            "Depth_file_destination": "RGBD/tmp/{}".format(depth_file_name)}

        return Response(data_packet)




        


