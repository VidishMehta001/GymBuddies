from django.apps import AppConfig


class LiveDemoConfig(AppConfig):
    name = 'live_demo'
