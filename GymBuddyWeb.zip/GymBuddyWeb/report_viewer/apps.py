from django.apps import AppConfig


class ReportViewerConfig(AppConfig):
    name = 'report_viewer'
