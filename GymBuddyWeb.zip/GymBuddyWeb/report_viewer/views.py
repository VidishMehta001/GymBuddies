from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response

# Create your views here.
def RV(request, *args, **kwargs):
    
    if request.method=="POST":
        # Get the video type
        video_type = request.GET.get("Video_Type")
        print(video_type)

        return render(request, "login.html", {})