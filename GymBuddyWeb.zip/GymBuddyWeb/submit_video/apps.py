from django.apps import AppConfig


class SubmitVideoConfig(AppConfig):
    name = 'submit_video'
