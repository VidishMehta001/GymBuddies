$("#Video-Type").click(function(){
    checkVideoType()
})

$(document).ready(function(){
    $("#upload-input").on("click", function(){
        console.log("Element Clicked!");

        // RGB-Video image of the RGB-D Video Input type
        $("#file-upload").change(function(){
            console.log("file-upload clicked!!");
            var filename = $('input[type=file]').val().split('\\').pop();
            console.log(filename);
            $("#file-name").empty()
            $("#file-name").append(
                `
                <p class="text" style="font-size: small; color: green; padding: 10px;">`+filename+`</p>
                `
            )

        })

        // Depth Map of the RGB-D Video Input type
        $("#file-upload-depth").change(function(){
            console.log("file-upload clicked!! and this is for the depth maps");
            var filename = $('#file-upload-depth').val().split('\\').pop();
            console.log(filename);
            $("#file-name-depth").empty()
            $("#file-name-depth").append(
                `
                <p class="text" style="font-size: small; color: green; padding: 10px;">`+filename+`</p>
                `
            )
        })


        // RGB Video input type
        $("#file-upload-rgb").change(function(){
            console.log("file-upload clicked!!");
            var filename = $('input[type=file]').val().split('\\').pop();
            console.log(filename);
            $("#file-name").empty()
            $("#file-name").append(
                `
                <p class="text" style="font-size: small; color: green; padding: 10px;">`+filename+`</p>
                `
            )
        })



    })
})


$(document).ready(function(){
    $("#next1").click(function(event){
        event.preventDefault();
        // hardcode the video files according to the Video Type
        if ($("#Video-Type").val()==="RGB"){
            var video = "Pushups.mp4"
            console.log(video);
            $("#confirm-video").empty();
            $("#Request-Input").html(
                `
                <div class="container" id="confirm-video" style="padding:12%; height:900px;">
                    <div class="row justify-content-center" style="width: 86%;">
                        <h3 class="h3" style="text-align: center;"> Please confirm input video file </h4>
                        <div id="video" style="padding: 2%; margin-left: 10%";>
                            <video width="720" height="480" src="https://www.youtube.com/watch?v=1BpYbEi2QcI" controls>
                                Your browser does not support the video tag.
                            </video>                        
                        </div>
                        <div class="submit">
                            <button class="btn btn-primary" id="submit">Submit Request</button>
                        </div>
                    </div>

                </div>
                `
            )


        }
        else if ($("#Video-Type").val()==="RGB-D"){
            var video = "Squats.mp4"
            var depth = "Squats_depth.mp4"
            $("#confirm-video").empty();
            $("#Request-Input").html(
                `
                <div class="container-fluid" id="confirm-video" style="padding:12%; height:1100px;">
                    <div class="row justify-content-center" style="width: 100%;">
                        <h3 class="h3" style="text-align: center;"> Please confirm input video file </h4>
                        <div class="row" style="padding: 2%;">
                            <div class="col-lg-8">
                                <div id="video" style="padding: 2%; margin-left: 2%";>
                                    <video width="420" height="300" src="https://www.youtube.com/watch?v=1BpYbEi2QcI" controls>
                                        Your browser does not support the video tag.
                                    </video>
                                </div>                 
                            </div>
                            <div class="col-lg-8">
                                <div id="video" style="padding: 2%; margin-left: 2%";>
                                    <video width="420" height="300" src="https://www.youtube.com/watch?v=1BpYbEi2QcI" controls>
                                        Your browser does not support the video tag.
                                    </video>
                                </div>
                            </div>
                        </div>              
                    </div>
                    <div class="submit" style="padding: 2%;">
                        <button class="btn btn-primary" id="submit">Submit Request</button>
                    </div>   
                </div>
                `
        )}        
    })
})




// Remember to add the csrf token in the future version
$(document).ready(function(){
    // For future troubleshooting
    $("#next").click(function(event) {

        //prevent page from refreshing
        event.preventDefault();
        
        // Validate the form
        isValidated = validateForm()
        console.log(isValidated);

        // csrf token initialisation for api endpoint call to django backend
        var $csrf_token = getCookie('csrftoken');
        console.log($csrf_token);

        // Create a new form data
        var formData = new FormData();

        // Get the files for sending to the backened
        if ($("#Video-Type").val() === "RGB") {
            var file = document.getElementById("file-upload-rgb").files[0];
            console.log(file);
            formData.append("VideoFile", file)
        }
        else if($("#Video-Type").val()==="RGB-D") {
            // first file is the video file
            var file = document.getElementById("file-upload").files[0];
            formData.append("VideoFile", file)
            // next file is the depth map
            var depthMap = document.getElementById("file-upload-depth").files[0];
            formData.append("DepthMap", depthMap)
        }
        // file type
        formData.append("File-type", $("#Video-Type").val())

        // Submission Url
        var request_job_url = "RequestJob"

        console.log(formData);

        // Make the Ajax call to Django
        $.ajax({
            type: "POST",
            url: request_job_url,
            headers: {
                'X-CSRFToken': $csrf_token
            },
            data: formData,
            cache: false,
            dataType: "json",
            contentType: false,
            processData: false,
            success: function(data){
                console.log(data);
                $("#Submitted-Request").empty();
                if ($("#Video-Type").val() === "RGB") {
                    file_name = data['File_name']
                    file_destination = data['File_destination']
                    $("#Submitted-Request").append(
                        `
                        <div class="container">
                            <div class="row">
                                <div id="video">
                                    <video controls autoplay>
                                        <source src="/media/`+file_destination+`" type="video/mp4">
                                    </video>
                                </div>
                            </div>
                            <div align="center" class="row" style="padding: 10px; text-align: center;">
                                <Button class="btn btn-primary" id="Request-Submit" style="align: center;">Confirm & Submit</Button>
                            </div>
                        </div>
                                
                        `
                    )
                } else {
                    video_file_name = data['Video_file_name'];
                    depth_file_name = data['Depth_file_name'];
                    video_file_destination = data['Video_file_destination'];
                    depth_file_destination = data['Depth_file_destination'];
                    console.log(depth_file_destination);
                    $("#Request-Input").append(
                        `
                        <div class="container" id="Submitted-Request">
                            <div class="row">
                                <div class="col-lg-4">
                                    <div id="video">
                                        <video controls autoplay>
                                            <source src="/media/`+video_file_destination+`" type="video/mp4">
                                        </video>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-4">
                                    <div id="video">
                                        <video controls autoplay>
                                            <source src="/media/`+depth_file_destination+`" type="video/mp4">
                                        </video>
                                    </div>
                                </div>
                            </div>
                            <div align="center" class="row" style="padding: 10px; text-align: center;">
                                <Button class="btn btn-primary" id="Submit-Request-depth">Confirm & Submit</Button>
                            </div>
                        </div>
                                
                        `
                        
                        
                    )

                }

            }
        })
    })
})



function validateForm(){
    console.log("Validating the form!");
    var isValidated = true;
    console.log($("#Video-Type").val())
    if ($("#Video-Type").val()==="RGB-D"){

        // Validate that input video is provided
        if ($("#file-upload").length===0){
            var isValidated = false;
            alert("Please include a valid input video file");
            return isValidated
        }
        
        // Validate that the depth map is present
        if ($("#file-upload-depth").lenght===0){
            var isValidated = false;
            alert("Please upload a valid depth map")
            return isValidated
        }
    }
    else if ($("#Video-Type").val()==="RGB") {
        // Validate that the input video is provided
        console.log("Its coming here!!")
        if ($("#file-upload-rgb").length===0){
            var isValidated = false;
            alert("Please upload a valid video");
            return isValidated
        }

    }

    return isValidated
}


function checkVideoType(){
    if ($("#Video-Type").val() === "RGB-D"){
        $("#upload-input").empty()
        $("#upload-input").append(
            `
            <div class="col-sm-6" id="RGB-Video-Upload">
                <label for="file-upload" class="custom-file-upload" style=" padding: 10px; border: 1px solid #ccc;
                display: inline-block;
                cursor: pointer;">
                    <i class="fa fa-cloud-upload"></i> Video Upload
                </label>
                <input id="file-upload" class="custom-file-input" type="file" size="60">
                <div id="file-name">
                </div>
            </div>
            <div class="col-sm-6" id="depth-file-upload">
                <label for="file-upload-depth" class="custom-file-upload" style=" padding: 10px; border: 1px solid #ccc;
                display: inline-block;
                cursor: pointer;">Depth Map Upload
                </label>
                <input id="file-upload-depth" class="custom-file-input" type="file" size="60">
                <div id="file-name-depth">
                </div>
            </div>
            `
        )
    }
    else if($("#Video-Type").val() === "RGB"){
        $("#upload-input").empty()
        $("#upload-input").append(
                `
                <div id="RGB-Video-Upload">
                    <label for="file-upload-rgb" class="custom-file-upload" style=" padding: 10px; border: 1px solid #ccc;
                    display: inline-block;
                    cursor: pointer;">
                        <i class="fa fa-cloud-upload"></i> Video Upload
                    </label>
                    <input id="file-upload-rgb" class="custom-file-input" type="file" size="60">
                    <div id="file-name">
                    </div>
                </div>
                `
        )

    }
}


function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = jQuery.trim(cookies[i]);
            // Does this cookie string begin with the name we want?
            if (cookie.substring(0, name.length + 1) == (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}


// Submit the video after confirming
$(document).ready(function(){
    $("#Submit-Request-depth").click(function(event){
        event.preventDefault();

        console.log("Button clicked")

        var depth_file_name = $('#file-upload-depth').val().split('\\').pop();
        var rgb_file_name = $("#file-upload").val().split('\\').pop();
        // console.log(depth_file_name, rgb_file_name);

        // form data
        var submit_form = new FormData();

        // Append the file names
        submit_form.append("RGB_Video", rgb_file_name);
        submit_form.append("Depth_Map", depth_file_name);

        // Initialise a newu url for calling the job
        submit_job_url = "ProcessJob"
        var $csrf_token = getCookie('csrftoken');

        // Send the parse message to the service script.
        $.ajax({
            type: "GET",
            url: submit_job_url,
            headers: {
                'X-CSRFToken': $csrf_token
            },
            dataType: "json",
            contentType: false,
            processData: false,
            sucess: function(data){
                console.log(data);
            }
            })
    })
})















// ajax call to endpoint for saving video in the media folder







// $("#depth-file-upload").on("click", function(){
//     $(document).ready(function(){
//         $("#file-upload-depth").change(function(){
//             console.log("Its coming here!!")
//             var filename = $('input[type=file]').val().split('\\').pop();
//             console.log(filename)
//             $("#file-name-depth").empty()
//             $("#file-name-depth").append(
//                 `
//                 <p class="text" style="font-size: small; color: green;">`+filename+`</p>
//                 `
//             )
//         })
//     })

// })

// $("#RGB-Video-Upload").on("click", function(){
//     console.log("RGB video to be uploaded")
//     $("#file-upload-depth").change(function(){
//         console.log("Its coming here!!")
//         var filename = $('input[type=file]').val().split('\\').pop();
//         console.log(filename)
//         $("#file-name").empty()
//         $("#file-name").append(
//             `
//             <p class="text" style="font-size: small; color: green;">`+filename+`</p>
//             `
//         )
//     })

// })




