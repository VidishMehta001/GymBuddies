from django.shortcuts import render


# Create your views here.
def submit_video_landing_page(request, *args, **kwargs):
    return render(request, 'SubmitVideo.html', {})

    