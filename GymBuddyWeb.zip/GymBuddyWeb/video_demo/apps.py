from django.apps import AppConfig


class VideoDemoConfig(AppConfig):
    name = 'video_demo'
